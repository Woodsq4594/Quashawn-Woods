print("Hello World")
print()

# Create simple variables / actually objects
a = 28
print(type(a))
print(a)
print()

a = 2.800
print(type(a))
print(a)
print()

a = 280000000000000000000000000000
print(type(a))
print(a)
print()

a = "Hello World"
print(type(a))
print(a)
print()



