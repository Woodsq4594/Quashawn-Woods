[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/n58pCkUw)
# CYBV473 - Scripting Assignment #1 - String Search Operations

One of the key elements of digital investigation is searching.  
Thus, for this week one assignment you are going to create a simple string search script.  
A sample script has been provided to get you started, you are to complete the script and submit:

1. Your `.py` file  
2. Screenshot from within your IDE demonstrating script execution.  

The detailed requirements are stated in the `wk1_script.py` script.  

Good luck
